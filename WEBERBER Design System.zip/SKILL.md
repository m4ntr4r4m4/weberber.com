---
name: weberber-design
description: Use this skill to generate well-branded interfaces and assets for WEBERBER (artesanía bereber hecha a mano — handmade Moroccan home goods, Madrid + Atlas Mountains), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Key files:
- `README.md` — full content & visual foundations, iconography rules.
- `colors_and_type.css` — drop-in tokens (`--primary #a4243b`, `--font-serif Playfair Display`, `--font-sans Inter`) and semantic classes (`.wm-h1`, `.wm-eyebrow`, `.wm-rule`, etc.).
- `assets/logo-weberber.svg` — the brand mark (single-color, tints via `currentColor`).
- `ui_kits/website/` — pixel-faithful Next.js → React recreation of the marketing site, component by component.
- `preview/` — small sample cards (one per token / per component) you can copy from.

Voice cheat sheet:
- Handmade but high end. Editorial luxury, not craft fair.
- Wordmark always ALL-CAPS WEBERBER. Headlines in Playfair Display Bold. Body in Inter.
- One accent color (cherry rose `#a4243b`) used everywhere — do not invent a second.
- Photography is warm, inhabited, sun-touched. Never product on white.
- Corners 4–8px. Shadows shallow. Animations quiet.
- No emoji in body copy. Lucide icons (1.5px stroke) for utility glyphs.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
