// Visit.jsx — atelier invitation. Letterform stamp, fine details, no boxed list.
const Visit = () => (
  <section style={{ padding: "160px 40px", background: "#fff" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.05fr", gap: 96, alignItems: "center" }}>
      <div>
        <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--primary)", marginBottom: 22 }}>The Invitation</div>
        <h2 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: "clamp(40px, 4.5vw, 60px)", lineHeight: 1.08, margin: 0, letterSpacing: "-.015em", color: "var(--fg-1)" }}>
          Tea, mint,<br/><em style={{ fontWeight: 400 }}>and the loom at work.</em>
        </h2>
        <p style={{ fontSize: 17, lineHeight: 1.8, color: "var(--fg-2)", fontWeight: 300, margin: "32px 0 48px", maxWidth: 460 }}>
          We host a small number of guests at the atelier each season. By appointment, never in groups larger than four — the looms keep working, and we don't ask the women to perform.
        </p>
        <div style={{ display: "grid", gap: 22, marginBottom: 48 }}>
          {[
            ["Atelier",     "Aït Bouguemez Valley, High Atlas"],
            ["By post",     "Contact@weberber.com"],
            ["By voice",    "+212 624 219 261"],
            ["Hours",       "Tuesday — Saturday, by appointment"],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: 24, paddingBottom: 18, borderBottom: "1px solid rgba(0,0,0,.08)" }}>
              <div style={{ fontSize: 10, letterSpacing: ".28em", textTransform: "uppercase", color: "var(--fg-3)", paddingTop: 4 }}>{k}</div>
              <div style={{ fontFamily: "var(--font-serif)", fontSize: 18, color: "var(--fg-1)" }}>{v}</div>
            </div>
          ))}
        </div>
        <a href="#" style={{ fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", color: "var(--fg-1)", textDecoration: "none", borderBottom: "1px solid var(--fg-1)", paddingBottom: 6 }}>Request an Appointment</a>
      </div>
      <div style={{ position: "relative" }}>
        <img src="https://admin.moroccan-carpet.com/wp-content/uploads/2025/07/DSC_2859-1-1120x800-1.jpg" alt="Atelier" style={{ width: "100%", aspectRatio: "4/5", objectFit: "cover", display: "block" }} />
        {/* postage-stamp ornament */}
        <div style={{ position: "absolute", top: 24, right: 24, width: 96, height: 96, border: "1px solid rgba(255,255,255,.6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 13, lineHeight: 1.3, textAlign: "center", padding: 8 }}>
          Maison<br/>WEBERBER<br/><span style={{ fontStyle: "normal", fontSize: 9, letterSpacing: ".22em", textTransform: "uppercase" }}>Est. 1962</span>
        </div>
      </div>
    </div>
  </section>
);
window.Visit = Visit;
