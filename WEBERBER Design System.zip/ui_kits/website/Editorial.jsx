// Editorial.jsx — full-bleed editorial spread breaking the rhythm between sections
const Editorial = () => (
  <section style={{ background: "#fafaf7", padding: "160px 40px", position: "relative" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "5fr 4fr", gap: 4, alignItems: "stretch" }}>
      <div style={{ position: "relative", minHeight: 720 }}>
        <img src="https://admin.moroccan-carpet.com/wp-content/uploads/2024/08/DSC4382-1-edited.jpg" alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
      </div>
      <div style={{ background: "#1a1814", color: "#fff", padding: "80px 64px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--primary-300)", marginBottom: 22 }}>The Journal · N° 04</div>
          <h3 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: 40, lineHeight: 1.15, margin: 0, letterSpacing: "-.01em" }}>
            On the colour of <em>madder root</em>, and why no two reds are alike.
          </h3>
          <p style={{ fontSize: 16, lineHeight: 1.75, color: "rgba(255,255,255,.7)", fontWeight: 300, marginTop: 28 }}>
            A field note from Khadija, our master dyer, on the eight months between digging up a root and pulling a finished skein from the cauldron.
          </p>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 48, paddingTop: 32, borderTop: "1px solid rgba(255,255,255,.15)" }}>
          <div style={{ fontSize: 10, letterSpacing: ".28em", textTransform: "uppercase", color: "rgba(255,255,255,.5)" }}>Spring 2026 · 8 min read</div>
          <a href="#" style={{ color: "#fff", fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,.7)", paddingBottom: 4 }}>Read →</a>
        </div>
      </div>
    </div>
  </section>
);
window.Editorial = Editorial;
