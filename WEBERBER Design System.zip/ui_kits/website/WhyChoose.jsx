// WhyChoose.jsx — editorial portrait spread with quote, signature, hairline list
const features = [
  { num: "01", title: "Hand-knotted",   desc: "By women cooperatives in Aït Bouguemez & Boujad." },
  { num: "02", title: "Natural dyes",   desc: "Madder root, indigo, walnut husk, pomegranate." },
  { num: "03", title: "Label STEP",     desc: "Independently certified fair-trade since 2018." },
  { num: "04", title: "Lifetime care",  desc: "Complimentary cleaning & repair, in perpetuity." },
];

const WhyChoose = () => (
  <section style={{ padding: "160px 40px", background: "#fff" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1.05fr 1fr", gap: 96, alignItems: "center" }}>
      <div style={{ position: "relative" }}>
        <img src="https://admin.moroccan-carpet.com/wp-content/uploads/2025/07/011-1-1120x800-1.jpg" alt="Atelier" style={{ width: "100%", aspectRatio: "4/5", objectFit: "cover", display: "block" }} />
        <div style={{ position: "absolute", left: -28, bottom: -28, background: "#fafaf7", padding: "24px 32px", maxWidth: 280, borderLeft: "1px solid var(--primary)" }}>
          <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, lineHeight: 1.5, color: "var(--fg-1)" }}>"A rug is not made — it is grown, knot by knot, prayer by prayer."</div>
          <div style={{ fontSize: 10, letterSpacing: ".26em", textTransform: "uppercase", color: "var(--fg-3)", marginTop: 14 }}>Fatima — Master Weaver</div>
        </div>
      </div>
      <div>
        <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--primary)", marginBottom: 22 }}>The House</div>
        <h2 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: "clamp(40px, 4.5vw, 60px)", lineHeight: 1.08, margin: "0 0 32px", color: "var(--fg-1)", letterSpacing: "-.015em" }}>
          Three generations,<br/><em style={{ fontWeight: 400 }}>one unbroken thread.</em>
        </h2>
        <p style={{ fontSize: 17, lineHeight: 1.8, color: "var(--fg-2)", fontWeight: 300, marginBottom: 48 }}>
          We do not buy from middlemen. We do not approximate. Every rug is signed by the family who tied its last knot — and we pay them, directly, before the loom is cut down.
        </p>
        <div style={{ display: "grid", gap: 0 }}>
          {features.map((f, i) => (
            <div key={f.num} style={{ display: "grid", gridTemplateColumns: "60px 1fr", gap: 28, padding: "24px 0", borderTop: "1px solid rgba(0,0,0,.08)", borderBottom: i === features.length - 1 ? "1px solid rgba(0,0,0,.08)" : "none" }}>
              <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, color: "var(--primary)" }}>{f.num}</div>
              <div>
                <div style={{ fontSize: 16, fontWeight: 500, color: "var(--fg-1)", marginBottom: 4 }}>{f.title}</div>
                <div style={{ fontSize: 14, color: "var(--fg-2)", fontWeight: 300, lineHeight: 1.6 }}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);
window.WhyChoose = WhyChoose;
