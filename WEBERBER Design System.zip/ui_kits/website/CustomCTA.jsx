// CustomCTA.jsx — full-bleed dark editorial spread, no rounded corners, large serif, hairline list
const CustomCTA = () => (
  <section style={{ position: "relative", minHeight: 720, background: "#1a1814", color: "#fff", overflow: "hidden" }}>
    <div style={{ position: "absolute", inset: 0 }}>
      <img src="https://admin.moroccan-carpet.com/wp-content/uploads/2025/07/DSC_7333-1-1120x800-1.jpg" alt="" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: .35 }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(26,24,20,.95) 0%, rgba(26,24,20,.7) 50%, rgba(26,24,20,.3) 100%)" }} />
    </div>
    <div style={{ position: "relative", maxWidth: 1280, margin: "0 auto", padding: "140px 40px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center" }}>
      <div>
        <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--primary-300)", marginBottom: 26 }}>À La Carte · For The Trade</div>
        <h2 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: "clamp(44px, 5vw, 72px)", lineHeight: 1.05, margin: 0, letterSpacing: "-.015em" }}>
          Commission a piece<br/><em style={{ fontWeight: 400 }}>made only for you.</em>
        </h2>
        <p style={{ fontSize: 17, lineHeight: 1.8, color: "rgba(255,255,255,.78)", fontWeight: 300, marginTop: 32, marginBottom: 48, maxWidth: 460 }}>
          Choose the dimensions, the palette, the motif. We will paint a watercolour rendering, you approve the loom, and twelve to twenty weeks later it arrives at your door — signed.
        </p>
        <div style={{ display: "grid", gap: 0, maxWidth: 460, marginBottom: 56 }}>
          {[
            ["01", "Custom dimensions", "Up to 16 × 20 ft, any proportion"],
            ["02", "Palette matching",  "Pantone, fabric swatch, or photograph"],
            ["03", "Trade programme",   "30% net for verified designers & studios"],
          ].map(([n, t, d], i) => (
            <div key={n} style={{ display: "grid", gridTemplateColumns: "44px 1fr", padding: "20px 0", borderTop: "1px solid rgba(255,255,255,.12)", borderBottom: i === 2 ? "1px solid rgba(255,255,255,.12)" : "none", gap: 20 }}>
              <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--primary-300)", fontSize: 16 }}>{n}</div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 500 }}>{t}</div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,.6)", fontWeight: 300, marginTop: 2 }}>{d}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 32, alignItems: "center" }}>
          <a href="#" style={{ color: "#fff", fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,.7)", paddingBottom: 6 }}>Begin a Commission</a>
          <a href="#" style={{ color: "rgba(255,255,255,.6)", fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", textDecoration: "none" }}>Trade Programme →</a>
        </div>
      </div>
      <div style={{ position: "relative", display: "none" }} />
    </div>
  </section>
);
window.CustomCTA = CustomCTA;
