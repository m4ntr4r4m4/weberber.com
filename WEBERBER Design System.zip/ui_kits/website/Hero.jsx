// Hero.jsx — full-bleed editorial; no overlay band. Letter-spaced headline, slow Ken-Burns photo, thin gold rule, single CTA.
const Hero = () => {
  return (
    <section style={{ position: "relative", height: "92vh", minHeight: 720, overflow: "hidden", background: "#0d0c0a" }}>
      <img src="https://admin.moroccan-carpet.com/wp-content/uploads/2024/08/DSC4382-1-edited.jpg" alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: .82, transform: "scale(1.06)", animation: "kenburns 28s ease-out infinite alternate" }} />
      <style>{`@keyframes kenburns{0%{transform:scale(1.04) translate(0,0)}100%{transform:scale(1.12) translate(-1%,-1%)}}`}</style>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(13,12,10,.55) 0%, rgba(13,12,10,.05) 35%, rgba(13,12,10,.0) 60%, rgba(13,12,10,.75) 100%)" }} />
      {/* corner ornaments */}
      <div style={{ position: "absolute", left: 40, top: 40, color: "rgba(255,255,255,.5)", fontSize: 11, letterSpacing: ".28em", textTransform: "uppercase" }}>Atlas Mountains · Est. Three Generations</div>
      <div style={{ position: "absolute", right: 40, top: 40, color: "rgba(255,255,255,.5)", fontSize: 11, letterSpacing: ".28em", textTransform: "uppercase" }}>N° 01 · Maison</div>

      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: "0 40px 96px", maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ maxWidth: 760 }}>
          <div style={{ color: "rgba(255,255,255,.7)", fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", marginBottom: 28, display: "flex", alignItems: "center", gap: 14 }}>
            <span style={{ width: 36, height: 1, background: "rgba(255,255,255,.5)" }} />
            The Spring Edit
          </div>
          <h1 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontStyle: "italic", color: "#fff", fontSize: "clamp(56px, 8vw, 112px)", lineHeight: 1.02, letterSpacing: "-0.015em", margin: 0 }}>
            A quiet luxury,<br/><span style={{ fontStyle: "normal", fontWeight: 500 }}>woven by hand.</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,.78)", fontSize: 17, lineHeight: 1.7, maxWidth: 520, marginTop: 36, fontWeight: 300 }}>
            Heirloom rugs, brass, ceramic and wood — sourced from the families we have worked with for three generations in the Atlas Mountains.
          </p>
          <div style={{ display: "flex", gap: 32, alignItems: "center", marginTop: 44 }}>
            <a href="#" style={{ color: "#fff", fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,.6)", paddingBottom: 6 }}>Discover the Collection</a>
            <a href="#" style={{ color: "rgba(255,255,255,.7)", fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", textDecoration: "none" }}>The Atelier →</a>
          </div>
        </div>
      </div>
    </section>
  );
};
window.Hero = Hero;
