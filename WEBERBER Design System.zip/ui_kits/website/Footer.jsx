// Footer.jsx
const shopLinks = ["All Products", "Rugs", "Pillows", "Candles", "Ceramic", "Argan Oil", "Brass Lamps"];
const companyLinks = ["About", "Contact", "Custom Orders"];

const Col = ({ title, items }) => (
  <div>
    <h4 style={{ fontSize: 13, fontWeight: 500, color: "#fff", textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 24, marginTop: 0 }}>{title}</h4>
    <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "grid", gap: 12 }}>
      {items.map(l => <li key={l}><a href="#" style={{ color: "var(--fg-4)", textDecoration: "none", fontSize: 14 }}>{l}</a></li>)}
    </ul>
  </div>
);

const Footer = () => (
  <footer style={{ background: "var(--bg-inverse)", color: "#fff" }}>
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "64px 24px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 40 }}>
        <div>
          <div style={{ fontFamily: "var(--font-serif)", fontWeight: 700, fontSize: 28, color: "#fff", marginBottom: 24, letterSpacing: "-0.02em" }}>WEBERBER</div>
          <p style={{ color: "var(--fg-4)", fontSize: 14, lineHeight: 1.6, marginBottom: 24 }}>
            Authentic handmade Moroccan home goods, crafted by 3rd generation Berber artisans. Rugs, pillows, candles, ceramics, argan oil & brass lamps.
          </p>
          <div style={{ display: "flex", gap: 16, color: "var(--dark-500)" }}>
            <a href="#" style={{ color: "inherit" }}><Icon.Instagram size={20} /></a>
            <a href="#" style={{ color: "inherit" }}><Icon.Pinterest size={20} /></a>
            <a href="#" style={{ color: "inherit" }}><Icon.Facebook size={20} /></a>
          </div>
        </div>
        <Col title="Shop" items={shopLinks} />
        <Col title="Company" items={companyLinks} />
        <div>
          <h4 style={{ fontSize: 13, fontWeight: 500, color: "#fff", textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 24, marginTop: 0 }}>WEBERBER</h4>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, color: "var(--fg-4)", fontSize: 14, display: "grid", gap: 4, marginBottom: 24 }}>
            <li>Madrid Malasaña 28004</li>
            <li>Spain</li>
            <li style={{ paddingTop: 4 }}><a href="mailto:Contact@weberber.com" style={{ color: "inherit" }}>Contact@weberber.com</a></li>
          </ul>
          <h4 style={{ fontSize: 13, fontWeight: 500, color: "#fff", textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 16, marginTop: 0 }}>Workshop</h4>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, color: "var(--fg-4)", fontSize: 14, display: "grid", gap: 4 }}>
            <li>20 Rue 22 Hay Karama 2</li>
            <li>15000, Khemisset</li>
            <li>Morocco</li>
          </ul>
        </div>
      </div>
    </div>
    <div style={{ borderTop: "1px solid var(--border-dark)" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "24px", display: "flex", justifyContent: "space-between", alignItems: "center", color: "var(--dark-500)", fontSize: 14 }}>
        <p style={{ margin: 0 }}>© {new Date().getFullYear()} WEBERBER</p>
        <div style={{ display: "flex", gap: 24 }}>
          <a href="#" style={{ color: "inherit", textDecoration: "none" }}>Privacy Policy</a>
          <a href="#" style={{ color: "inherit", textDecoration: "none" }}>Terms of Service</a>
        </div>
      </div>
    </div>
  </footer>
);
window.Footer = Footer;
