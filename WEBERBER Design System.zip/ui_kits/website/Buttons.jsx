// Buttons.jsx — Primary, outline, glass.
const btnBase = {
  display: "inline-flex", alignItems: "center", justifyContent: "center",
  fontFamily: "var(--font-sans)", fontWeight: 500, fontSize: 16,
  borderRadius: 4, cursor: "pointer", transition: "all 150ms",
  border: 0, textDecoration: "none", whiteSpace: "nowrap",
};

const Button = ({ variant = "primary", size = "md", children, onClick, href, ...rest }) => {
  const sizing = size === "lg"
    ? { padding: "16px 32px" }
    : size === "sm"
      ? { padding: "8px 16px", fontSize: 14 }
      : { padding: "12px 24px" };

  const variants = {
    primary: { background: "var(--primary)", color: "#fff" },
    outline: { background: "transparent", color: "var(--fg-1)", border: "2px solid var(--fg-1)" },
    glass: { background: "rgba(255,255,255,0.10)", color: "#fff", border: "1px solid rgba(255,255,255,0.30)", backdropFilter: "blur(4px)" },
    light: { background: "#fff", color: "var(--fg-1)", border: "1px solid var(--border-strong)" },
  };
  const hoverColor = {
    primary: "var(--primary-600)",
    outline: "var(--fg-1)",
    glass: "rgba(255,255,255,0.20)",
    light: "var(--bg-soft)",
  }[variant];

  const [hover, setHover] = React.useState(false);
  const sty = { ...btnBase, ...sizing, ...variants[variant] };
  if (hover) {
    if (variant === "primary" || variant === "glass" || variant === "light") sty.background = hoverColor;
    if (variant === "outline") { sty.background = hoverColor; sty.color = "#fff"; }
  }

  const Tag = href ? "a" : "button";
  return (
    <Tag href={href} onClick={onClick} style={sty} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} {...rest}>
      {children}
    </Tag>
  );
};

window.Button = Button;
