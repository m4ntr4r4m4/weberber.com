// TrustLogos.jsx — quieter, single line, hairline rule
const trustLogos = [
  { src: "https://admin.moroccan-carpet.com/wp-content/uploads/2025/06/CONDE-NAST-400x400.png", title: "Condé Nast Traveller" },
  { src: "https://admin.moroccan-carpet.com/wp-content/uploads/2025/01/COVER-MAGAZINE-400x400.png", title: "Cover Magazine" },
  { src: "https://admin.moroccan-carpet.com/wp-content/uploads/2025/01/LABEL-STEP-400x400.png", title: "Label STEP" },
  { src: "https://admin.moroccan-carpet.com/wp-content/uploads/2025/01/KOHAN-TEXTILE-400x400.png", title: "Kohan Textile" },
  { src: "https://admin.moroccan-carpet.com/wp-content/uploads/2025/01/MINISTRY-OF-TOURISM-400x400.png", title: "Ministry of Tourism" },
];
const TrustLogos = () => (
  <section style={{ padding: "72px 40px", background: "#fafaf7", borderTop: "1px solid rgba(0,0,0,.04)", borderBottom: "1px solid rgba(0,0,0,.04)" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto" }}>
      <p style={{ textAlign: "center", fontSize: 10, letterSpacing: ".34em", color: "var(--fg-3)", textTransform: "uppercase", marginBottom: 44 }}>As Featured In</p>
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", alignItems: "center", gap: 40 }}>
        {trustLogos.map(l => (
          <img key={l.title} src={l.src} alt={l.title} title={l.title}
            style={{ height: 56, objectFit: "contain", filter: "grayscale(1) brightness(.6)", opacity: 0.55, transition: "all 600ms" }}
            onMouseEnter={e => { e.currentTarget.style.filter = "grayscale(1) brightness(.4)"; e.currentTarget.style.opacity = 1; }}
            onMouseLeave={e => { e.currentTarget.style.filter = "grayscale(1) brightness(.6)"; e.currentTarget.style.opacity = 0.55; }} />
        ))}
      </div>
    </div>
  </section>
);
window.TrustLogos = TrustLogos;
