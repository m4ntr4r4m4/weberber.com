// ReviewsSlider.jsx — pull-quote editorial. One large serif quote, small portrait, gentle dot nav.
const press = [
  { quote: "The most thoughtfully sourced rugs I have laid in fifteen years of practice. The pieces feel inevitable in the room.", who: "Athena Calderone", role: "Interior Designer · EyeSwoon", img: "https://admin.moroccan-carpet.com/wp-content/uploads/2023/11/REVIEW-01-min-800x800.jpg" },
  { quote: "WEBERBER does not romance the romance — they let the cloth speak. Nothing else in our home draws comment so often.",   who: "Marie-Hélène",       role: "Private Client · Paris",        img: "https://admin.moroccan-carpet.com/wp-content/uploads/2023/11/REVIEW-02-min-800x800.jpg" },
  { quote: "An heirloom from the moment it arrived. The hand, the weight, the smell of the wool — it is exactly as promised.",     who: "James Whitcomb",     role: "Architect · London",            img: "https://admin.moroccan-carpet.com/wp-content/uploads/2023/11/REVIEW-03-min-800x800.jpg" },
  { quote: "We have specified WEBERBER on five projects this year. The trade programme is, frankly, embarrassingly generous.",      who: "Studio Saxony",       role: "Trade Partner · Brooklyn",       img: "https://admin.moroccan-carpet.com/wp-content/uploads/2023/11/REVIEW-04-min-800x800.jpg" },
  { quote: "Three generations is not a marketing line — you can feel it in every knot. The provenance card moved me to tears.",     who: "Lina Rossi",         role: "Editor · Cover Magazine",       img: "https://admin.moroccan-carpet.com/wp-content/uploads/2023/11/REVIEW-05-min-800x800.jpg" },
];

const ReviewsSlider = () => {
  const [idx, setIdx] = React.useState(0);
  const [auto, setAuto] = React.useState(true);
  React.useEffect(() => {
    if (!auto) return;
    const t = setInterval(() => setIdx(i => (i + 1) % press.length), 7000);
    return () => clearInterval(t);
  }, [auto]);
  const pause = () => { setAuto(false); setTimeout(() => setAuto(true), 14000); };
  const goto = i => { setIdx((i + press.length) % press.length); pause(); };
  const cur = press[idx];

  return (
    <section style={{ padding: "160px 40px", background: "#fafaf7" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--primary)", marginBottom: 18 }}>Words From Our Patrons</div>
        </div>
        <div style={{ position: "relative", textAlign: "center", minHeight: 380 }}>
          <div key={idx} style={{ animation: "fadeIn 800ms ease-out" }}>
            <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontWeight: 400, fontSize: "clamp(28px, 3.4vw, 44px)", lineHeight: 1.35, color: "var(--fg-1)", maxWidth: 920, margin: "0 auto", letterSpacing: "-.005em" }}>
              <span style={{ color: "var(--primary)", fontFamily: "var(--font-serif)", fontSize: "1.4em", lineHeight: 0, position: "relative", top: ".22em", marginRight: 6 }}>“</span>
              {cur.quote}
              <span style={{ color: "var(--primary)", fontFamily: "var(--font-serif)", fontSize: "1.4em", lineHeight: 0, position: "relative", top: ".22em", marginLeft: 4 }}>”</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 56, gap: 14 }}>
              <img src={cur.img} alt="" style={{ width: 56, height: 56, borderRadius: "50%", objectFit: "cover", filter: "grayscale(.3)" }} />
              <div style={{ fontFamily: "var(--font-serif)", fontSize: 16, color: "var(--fg-1)", fontStyle: "italic" }}>{cur.who}</div>
              <div style={{ fontSize: 10, letterSpacing: ".28em", textTransform: "uppercase", color: "var(--fg-3)" }}>{cur.role}</div>
            </div>
          </div>
          <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`}</style>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 12, marginTop: 56 }}>
          {press.map((_, i) => (
            <button key={i} onClick={() => goto(i)} aria-label={`Patron ${i + 1}`}
              style={{ width: 22, height: 1, background: i === idx ? "var(--fg-1)" : "rgba(0,0,0,.18)", border: 0, padding: 0, cursor: "pointer", transition: "300ms" }} />
          ))}
        </div>
      </div>
    </section>
  );
};
window.ReviewsSlider = ReviewsSlider;
