// WhatsAppFAB.jsx
const WhatsAppFAB = () => {
  const [hover, setHover] = React.useState(false);
  return (
    <a href="https://wa.me/212624219261" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"
       style={{ position: "fixed", bottom: 24, right: 24, zIndex: 50, width: 56, height: 56, background: hover ? "#1ebe57" : "#25D366", borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "var(--shadow-lg)", color: "#fff", transform: hover ? "scale(1.1)" : "scale(1)", transition: "all 200ms" }}
       onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <Icon.WhatsApp size={28} />
    </a>
  );
};
window.WhatsAppFAB = WhatsAppFAB;
