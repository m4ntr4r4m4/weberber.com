// Header.jsx — refined: thinner type, ample tracking, soft border
const Header = () => {
  const links = ["Shop", "Collections", "Custom Orders", "Journal", "About", "Contact"];
  return (
    <React.Fragment>
      <div style={{ background: "var(--bg-inverse)", color: "rgba(255,255,255,.85)", textAlign: "center", padding: "10px 12px", fontSize: 12, letterSpacing: ".18em", textTransform: "uppercase", fontWeight: 400 }}>
        Fair Trade Certified by Label STEP&nbsp;&nbsp;·&nbsp;&nbsp;Complimentary Worldwide Shipping
      </div>
      <header style={{ borderBottom: "1px solid rgba(0,0,0,.06)", background: "rgba(255,255,255,.92)", backdropFilter: "blur(8px)", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "0 40px", height: 88, display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center" }}>
          <nav style={{ display: "flex", gap: 36 }}>
            {links.slice(0,3).map(l => <a key={l} href="#" style={{ fontSize: 11, fontWeight: 500, letterSpacing: ".22em", textTransform: "uppercase", color: "var(--fg-2)", textDecoration: "none" }}>{l}</a>)}
          </nav>
          <a href="#" style={{ fontFamily: "var(--font-serif)", fontWeight: 500, fontSize: 28, letterSpacing: ".32em", color: "var(--fg-1)", textDecoration: "none", paddingLeft: ".32em" }}>WEBERBER</a>
          <div style={{ display: "flex", alignItems: "center", gap: 28, justifyContent: "flex-end", color: "var(--fg-2)" }}>
            {links.slice(3).map(l => <a key={l} href="#" style={{ fontSize: 11, fontWeight: 500, letterSpacing: ".22em", textTransform: "uppercase", color: "var(--fg-2)", textDecoration: "none" }}>{l}</a>)}
            <span style={{ width: 1, height: 18, background: "rgba(0,0,0,.1)" }} />
            <a href="#" style={{ fontSize: 11, fontWeight: 500, letterSpacing: ".22em", color: "var(--fg-2)", textDecoration: "none" }}>EN · ES</a>
            <a href="#" style={{ position: "relative", color: "inherit" }}>
              <Icon.Cart size={20} stroke={1.25} />
              <span style={{ position: "absolute", top: -8, right: -10, fontSize: 10, color: "var(--fg-1)" }}>(3)</span>
            </a>
          </div>
        </div>
      </header>
    </React.Fragment>
  );
};
window.Header = Header;
