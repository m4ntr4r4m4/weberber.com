// App.jsx — assembled marketing home (luxury edit).
const App = () => (
  <React.Fragment>
    <Header />
    <main>
      <Hero />
      <TrustLogos />
      <CategoryGrid />
      <WhyChoose />
      <Editorial />
      <CustomCTA />
      <ReviewsSlider />
      <Visit />
    </main>
    <Footer />
    <WhatsAppFAB />
  </React.Fragment>
);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
