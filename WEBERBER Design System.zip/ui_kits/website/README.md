# WEBERBER · Website UI Kit

Hi-fi recreation of weberber.com. Modular components, kept cosmetically faithful to the source codebase.

## Files
- `index.html` — entry. Loads React, Babel, all components in order.
- `Icons.jsx` — Lucide-style icon set + filled social glyphs.
- `Buttons.jsx` — `<Button variant="primary|outline|glass|light" size="sm|md|lg" />`.
- `Header.jsx` — Top primary announcement bar + sticky white nav with cart badge.
- `Hero.jsx` — Full-bleed photo with 60% black band, dual CTAs.
- `TrustLogos.jsx` — Press / certification row, grayscale → color on hover.
- `CategoryGrid.jsx` — Photo tiles, hover-zoom, gradient caption with reveal CTA.
- `WhyChoose.jsx` — 2-up: copy + 4 feature chips on `gray-50`.
- `CustomCTA.jsx` — Dark `gray-900` rounded card, eyebrow → H2 → check-list → primary CTA.
- `ReviewsSlider.jsx` — 3-up with center emphasis, auto-advance, dot nav.
- `Visit.jsx` — Workshop / contact two-up, with mail/WhatsApp/map-pin lines.
- `Footer.jsx` — Dark footer with 4-col layout: brand · shop · company · contact.
- `WhatsAppFAB.jsx` — Fixed bottom-right green chat bubble.
- `App.jsx` — Composes the homepage.

## Notes
- All components reference the design system variables in `../../colors_and_type.css` for color and type tokens.
- Photography is hot-linked from the brand's WordPress media (`admin.moroccan-carpet.com`).
- Components are simple cosmetic recreations — they do not persist cart, fetch products, or wire i18n. For production behavior see the original codebase under `app/` and `components/` at the project root.
