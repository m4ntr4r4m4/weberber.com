// CategoryGrid.jsx — editorial asymmetric grid with N° numerals, hairlines, refined hover
const cats = [
  { num: "I",   name: "Rugs",        sub: "Heirloom · Hand-knotted",  img: "https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?auto=format&fit=crop&q=80&w=1400", span: 2, height: 560 },
  { num: "II",  name: "Wood",        sub: "Carved cedar of the Atlas", img: "https://images.unsplash.com/photo-1578500351865-d6c3706f46bc?auto=format&fit=crop&q=80&w=900",  span: 1, height: 560 },
  { num: "III", name: "Ceramic",     sub: "Tamegroute & Fès",         img: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&q=80&w=900",  span: 1, height: 460 },
  { num: "IV",  name: "Brass",       sub: "Lanterns & lighting",      img: "https://images.unsplash.com/photo-1540981493580-8ea1113e9958?auto=format&fit=crop&q=80&w=900",  span: 1, height: 460 },
  { num: "V",   name: "Apothecary",  sub: "Argan, rose & amber",      img: "https://images.unsplash.com/photo-1608248593842-83b333792044?auto=format&fit=crop&q=80&w=900",  span: 1, height: 460 },
];

const CategoryTile = ({ num, name, sub, img, height }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <a href="#" style={{ position: "relative", display: "block", overflow: "hidden", height, textDecoration: "none", background: "#0d0c0a" }}
       onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: `url("${img}")`, backgroundSize: "cover", backgroundPosition: "center", transform: hover ? "scale(1.04)" : "scale(1.0)", transition: "transform 1200ms cubic-bezier(.2,.7,.2,1)", opacity: 0.94 }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(0,0,0,.05) 0%, rgba(0,0,0,.0) 35%, rgba(0,0,0,.65) 100%)" }} />
      <div style={{ position: "absolute", left: 28, top: 28, color: "rgba(255,255,255,.85)", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 14, letterSpacing: ".1em" }}>N° {num}</div>
      <div style={{ position: "absolute", left: 28, right: 28, bottom: 28, color: "#fff" }}>
        <div style={{ fontSize: 10, letterSpacing: ".28em", textTransform: "uppercase", color: "rgba(255,255,255,.75)", marginBottom: 10 }}>{sub}</div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
          <h3 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: 36, margin: 0, letterSpacing: "-.01em" }}>{name}</h3>
          <span style={{ fontSize: 11, letterSpacing: ".22em", textTransform: "uppercase", borderBottom: "1px solid rgba(255,255,255,.7)", paddingBottom: 4, transform: hover ? "translateX(0)" : "translateX(-8px)", opacity: hover ? 1 : .6, transition: "400ms" }}>Explore →</span>
        </div>
      </div>
    </a>
  );
};

const CategoryGrid = () => (
  <section style={{ padding: "140px 40px 120px", background: "#fafaf7" }}>
    <div style={{ maxWidth: 1280, margin: "0 auto" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", alignItems: "end", marginBottom: 64, gap: 40 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: ".34em", textTransform: "uppercase", color: "var(--fg-3)", marginBottom: 18 }}>The Collections</div>
          <h2 style={{ fontFamily: "var(--font-serif)", fontWeight: 400, fontSize: "clamp(40px, 5vw, 68px)", lineHeight: 1.05, margin: 0, color: "var(--fg-1)", letterSpacing: "-.015em" }}>
            Five rooms,<br/><em style={{ fontWeight: 400 }}>one philosophy.</em>
          </h2>
        </div>
        <p style={{ color: "var(--fg-2)", fontSize: 17, lineHeight: 1.75, fontWeight: 300, maxWidth: 460, justifySelf: "end" }}>
          Each piece is signed by the family who made it. We name our makers — because the name on a label should mean something.
        </p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 4 }}>
        <div style={{ gridColumn: "span 2" }}><CategoryTile {...cats[0]} /></div>
        <div><CategoryTile {...cats[1]} /></div>
        <div><CategoryTile {...cats[2]} /></div>
        <div><CategoryTile {...cats[3]} /></div>
        <div><CategoryTile {...cats[4]} /></div>
      </div>
      <div style={{ textAlign: "center", marginTop: 72 }}>
        <a href="#" style={{ fontSize: 12, letterSpacing: ".26em", textTransform: "uppercase", color: "var(--fg-1)", textDecoration: "none", borderBottom: "1px solid var(--fg-1)", paddingBottom: 6 }}>The Complete Catalogue</a>
      </div>
    </div>
  </section>
);
window.CategoryGrid = CategoryGrid;
