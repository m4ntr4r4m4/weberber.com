# WEBERBER Design System

> **WEBERBER** — *artesanía bereber hecha a mano.*
> Authentic, handmade Moroccan home goods, crafted by 3rd-generation Berber artisans in the Atlas Mountains. Sold from a Madrid storefront, shipped worldwide.

This design system is built from real source material — not guesses. It is the toolkit any agent or designer should use when producing artifacts (mocks, slides, web pages, ads, packaging) on behalf of WEBERBER.

---

## What WEBERBER is

- **Category:** Hand-woven rugs, pillows, candles, ceramics, brass lamps, argan oil — Moroccan home & living.
- **Tone:** Handmade but high end. The wares are folk-craft; the presentation is editorial / luxury hospitality.
- **Provenance:** Family workshop in Khemisset, Morocco. Madrid (Malasaña) flagship.
- **Trust:** Fair Trade certified by Label STEP; featured in Condé Nast Traveller, Cover Magazine, Kohan Textile Journal, Morocco Ministry of Tourism.
- **Languages:** Multi-locale (next-intl with RTL support — Arabic-ready).
- **Channels:** weberber.com (Next.js + Shopify + Stripe), Instagram, Pinterest, Facebook, WhatsApp (+212 624 219 261).

## Sources used

- Logo (SVG): provided directly by user (`uploads/LOGO (1).svg` → `assets/logo-weberber.svg`).
- Codebase: **github.com/m4ntr4r4m4/weberber.com** (Next.js 16, React 19, Tailwind 4, next-intl, Shopify, Stripe, lucide-react). Imported under repo paths in this project — see `app/`, `components/`, `messages/`.
- Imagery: hot-linked from `admin.moroccan-carpet.com` (the brand's WordPress media admin) and Unsplash placeholders for category tiles.
- Brand voice: copy in `messages/en/common.json`.

---

## Index — what's in this folder

| Path | Purpose |
|---|---|
| `README.md` | This file. |
| `SKILL.md` | Skill manifest (cross-compatible with Claude Code Agent Skills). |
| `colors_and_type.css` | Source-of-truth tokens: colors, type scale, semantic classes (`.wm-h1`, `.wm-eyebrow`, etc.). |
| `assets/` | Logo, sub-assets, copied iconography. |
| `preview/` | Per-token / per-component cards rendered to populate the Design System tab. |
| `ui_kits/website/` | Hi-fi recreation of the marketing site (header, footer, hero, category grid, CTA, customizer). |
| `app/`, `components/`, `messages/`, `i18n.ts` | Imported source from the production codebase, read-only reference. |

---

## CONTENT FUNDAMENTALS

The brand voice is **handmade but high end** — read like a small atelier that ships globally. It is confident, declarative, and proud of provenance. Never breezy, never start-up-cute.

### Voice traits
- **Declarative, present tense.** "Authentic Moroccan Home & Living." "Handcrafted by 3rd-generation Berber artisans." Statements of fact, not promises.
- **Concrete provenance.** Every claim is anchored to a place, a person, a certification. *Atlas Mountains. Khemisset. Label STEP. 3rd generation.*
- **First-person plural ("we") for the brand, second-person ("you") for the visitor.** "*We* invite *you* to visit our workshop." "Why choose *us*."
- **Em-dash and serif rhythm.** Sentences breathe — they aren't run-on, but they aren't clipped either.
- **No emoji in body copy.** Emoji *do* appear sparingly as compact icons in the live site (✋ 🏔️ 🤝 🌿 ✓ 📧 💬 📍) — these are placeholders/glyph-icons, not voice. New designs should prefer real SVG icons (Lucide); see ICONOGRAPHY.

### Casing
- **WEBERBER** — wordmark is ALL CAPS, always. Never "Weberber," never "weberber."
- **Section eyebrows** — ALL CAPS, wide tracking (`uppercase tracking-wider`). e.g. `FOR INTERIOR DESIGNERS`, `EXPERIENCE MOROCCO`.
- **Nav links** — UPPERCASE with `tracking-wide`.
- **Headings** — Title Case, serif. e.g. *Authentic Moroccan Home & Living*, *Visit Our Workshop*.
- **Body** — sentence case.
- **CTAs** — Title Case, no period. *Shop Now*, *View Collections*, *Inquire Now*, *Contact Us*.

### Vocabulary you will use
- handcrafted, handwoven, handmade, hand-knotted, bespoke
- artisans (never "craftspeople" or "makers"), Berber (capitalized), atelier, workshop
- Atlas Mountains, Morocco, Khemisset, Madrid
- 3rd-generation, generations, ancient, traditional, heritage
- Fair Trade, Label STEP, certified
- wool, brass, argan, ceramic, terracotta, saffron

### Vocabulary you will avoid
- "boho," "bohemian," "ethnic" — clichéd and reductive
- "exotic," "tribal" — colonial vocabulary
- "vibes," "drop," "iconic" — startup-speak
- "AI," "smart," "platform" — wrong category
- generic SaaS verbs: "transform" is OK once per page; "elevate," "unlock," "empower" — never

### Specific examples (from the live site)
- Hero: *"Authentic Moroccan Home & Living. Transform your space with handcrafted Moroccan treasures — from artisan rugs and pillows to scented candles, ceramics, argan oil products, and brass lamps."*
- Why: *"For over three generations, our family has been crafting the finest Moroccan home goods in the Atlas Mountains. Each piece tells a story of ancient Berber traditions, skilled hands, and patterns passed down through centuries."*
- Custom CTA: *"Working on a special project? We offer bespoke design services for rugs, ceramics, and more. Choose your size, colors, and patterns."*
- Announcement bar: *"Fair Trade Certified by Label STEP | Free Worldwide Shipping"*
- Footer tagline: *"Authentic handmade Moroccan home goods, crafted by 3rd generation Berber artisans."*

### Microcopy patterns
- CTA buttons: 2–3 words, Title Case. *Shop Now · View Collections · Inquire Now · Contact Us · Add Custom Rug to Cart*.
- Stat-style proof: *"Join 934+ happy customers who transformed their homes with our products."* (specific number > round number)
- Contact lines use a small glyph + label + value: `📧 Contact@weberber.com`, `💬 +212 624 219 261`, `📍 Atlas Mountains, Morocco`.

---

## VISUAL FOUNDATIONS

The visual system is **editorial luxury** — Playfair Display headlines, Inter body, generous whitespace, and one disciplined accent color (cherry rose `#a4243b`). It looks like a Condé Nast Traveller feature, not a craft fair.

### Color
- **Primary — "cherry rose" `#a4243b`.** Used for CTAs, eyebrows, the announcement bar, the underline rule below H2s, the active dot, and the WhatsApp/cart count badge. There is a full 50–900 ramp; hover lifts to `--primary-600` (`#ca3354`).
- **Neutrals.** Near-white surfaces (`#ffffff`, `gray-50 #f9fafb`-ish via `--bg-muted`), ink text (`gray-900 #111827`), supporting `gray-600/500/400`. The footer / custom CTA flips to `gray-900 #1a1a1a` with white type and `gray-400` body.
- **Materia palette** (rug-customizer dyes — these are *artwork colors*, not UI colors): cream wool `#F5F5DC`, charcoal `#2C3539`, terracotta `#E2725B`, atlas blue `#007FFF`, saffron `#F4C430`, olive `#808000`. Use these inside hand-drawn rug graphics; do not promote them to UI surfaces.
- **Semantic.** Success/shipping = green-600 `#16a34a`; WhatsApp brand-green = `#25D366`. No yellow warning, no red error in the live site.
- **Color vibe of imagery.** Warm, sun-touched, slightly desaturated — natural light on wool, brass, terracotta, indigo. Never cool or grey-cast. No B&W photography. No grain filter. Photography always has a human subject or a warm interior, never product on white seamless.

### Typography
- **Display — Playfair Display.** Bold/black weight for H1/H2, semibold for H3. Italic available for editorial pull-quotes; not yet used.
- **Body — Inter.** 400/500 the workhorses, 600 for emphasis.
- **WEBERBER wordmark** — Playfair, **font-bold**, **tracking-tight**, set as plain type (no logotype lockup file).
- **Eyebrows / nav** — Inter, uppercase, tracking-wider/widest.
- Scale: 12 / 14 / 16 / 18 / 20 / 24 / 30 / 36 / 48 / 60 px.
- Hero scales `4xl → 6xl`. Section H2s scale `3xl → 4xl`. Lead paragraphs are `lg → xl`.

### Spacing
- **8px baseline.** Tailwind spacing scale.
- Sections are `py-20` (80px) on desktop, `py-16` on mobile. Inside cards, padding is `p-8` to `p-14` for hero panels.
- The hero band is `h-[85vh] min-h-[600px]`.
- Container is `mx-auto px-4` capped at ~1200px.
- Grids use `gap-8` for category tiles, `gap-16` for hero/two-up sections, `gap-3/4` for chip rows.

### Backgrounds
- **Mostly flat white**, with `gray-50` alternating bands to break sections.
- **Photography hero** — full-bleed image with a black 60% overlay band ("Text Band with Opacity") rather than a vignette. The text band is *the* hero device.
- **Gradient is rare** — only a `from-black/80 to-transparent` bottom-fade on category-tile captions for legibility. No purple/blue gradients. No mesh gradients.
- **No repeating Berber-pattern wallpaper** in the current site. (We resist the temptation; over-stylized backgrounds make the goods feel themed.) If a pattern is needed, place it as artwork inside an image card, never as page chrome.

### Animation & motion
- **Transitions are quiet.** `transition-colors`, `transition-transform`, `transition-all duration-300/500/700`. No bounces, no springs, no parallax.
- **Hover lift** — category tiles scale to 1.05 over 700ms (slow, considered).
- **Hover overlay** — overlay alpha goes 20% → 40%; caption fades and slides up 8px.
- **Reviews carousel** auto-advances every 4s, snap to slide on click, 500ms ease-out.
- **No entrance animations** on scroll. No skeleton shimmers.

### Hover & press
- **Buttons:** `bg-primary` → `bg-primary-600` on hover (one shade darker). Outline buttons fill in on hover (`bg-gray-900 hover:text-white`). No shadow shift.
- **Links:** `text-gray-700 hover:text-primary` — color shift only.
- **Icon buttons:** opacity 70% → 100%, or grayscale → color (trust logos).
- **WhatsApp FAB:** scales to 1.10 + bg darkens.
- **Press / active:** none custom. Default browser focus rings retained on inputs; CTAs do not shrink.

### Borders, dividers, shadows
- **Borders are thin and warm-grey.** `border-gray-100 #f3f4f6` for dividers (header underline, card edges, the chip-grid hairlines). `border-gray-200` for stronger edges. `border-2 border-gray-900` for outline CTA buttons.
- **Shadow ladder is shallow.** `shadow` on review cards, `shadow-sm` on customizer panels, `shadow-md` on primary buttons, `shadow-lg` on the active reviews slide and the WhatsApp FAB. **No inner shadows.** No glassmorphism beyond a single `backdrop-blur-sm` on a "Live Preview" badge.
- **Capsules vs. protection gradients** — the brand uses **capsules** (rounded-pill chips, `bg-white/90 backdrop-blur` over imagery) for badges, and a single bottom-fade gradient on category tiles. Both are sparing.

### Transparency & blur
- Used surgically: `bg-white/90 backdrop-blur` on photo-overlay chips; `bg-white/10 backdrop-blur-sm` on the secondary hero CTA; `bg-black/60` band on the hero. Otherwise surfaces are opaque.

### Corner radii
- **Default rounded `4px`** (Tailwind `rounded`) on most CTAs, image tiles, and chips.
- **`rounded-lg` `8px`** on the dark Custom-CTA card and the customizer panels (`rounded-xl 12px`).
- **`rounded-full`** on dots, color swatches, FAB, and avatar/badge counters.
- **No 24px+ "pillowy" radii.** This brand isn't soft — it's editorial.

### Cards
- White surface · `rounded-lg` · `border border-gray-100` · `shadow-sm` · `p-6` to `p-8`.
- Image-led cards have **no border** — the image is the edge — and a `shadow-md` lift.
- Dark "feature" cards: `bg-gray-900 text-white rounded-lg overflow-hidden`, two-column with imagery on one side, copy on the other. Eyebrow → H2 → lead → checklist (✓) → primary CTA.

### Layout rules / fixed elements
- **Sticky header** at `top-0 z-50` with thin `border-b border-gray-100`. White, never glassy.
- **Top announcement bar** — full-width primary, white text, 14px, single sentence with `|` separators.
- **WhatsApp FAB** — fixed bottom-right `bottom-6 right-6 z-50`, 56px circle, `#25D366`, hard shadow, scales on hover.
- **Footer** — full-width `bg-gray-900` with 4-col grid of brand · shop · company · contact + bottom utility row.

### Ultra-quick visual tells (use these to sanity-check any new artifact)
- Headline is Playfair-bold; subhead is Inter-regular gray-600.
- One red accent — the same red — repeats: announcement bar, CTA, eyebrow, rule.
- Photography is warm and inhabited, never product-on-white.
- Corners are 4–8px. Not 16px.
- Shadows are subtle. Buttons don't lift on press.
- Emoji are tolerated only as glyph-icons inside chips, not in sentence flow.

---

## ICONOGRAPHY

The codebase imports **`lucide-react`** as the primary icon library, paired with **inline SVGs** that are hand-authored for specific glyphs (carts, chevrons, social glyphs, the WhatsApp mark). Emoji are used as a fallback for "feature chips" (✋ 🏔️ 🤝 🌿 ✓ 📧 💬 📍) — flag those as substitutions when designing new artifacts.

### Where to draw icons
1. **Lucide React (`lucide-react@1.x`)** — already a dependency. Use for utility glyphs: cart, search, menu, x, check, chevron-left/right, globe, mail, phone, map-pin, instagram, facebook, etc. Stroke-based, 1.5px stroke weight, rounded line caps. CDN: `https://unpkg.com/lucide-static@latest/icons/<name>.svg`.
2. **Inline brand SVGs** — bespoke marks (the `M16 11V7a4 4 0 00-8 0v4…` cart, social glyphs in the footer, the WhatsApp glyph). When a glyph is brand-specific (Pinterest's `P`, Instagram's camera-square), use the original brand SVG path rather than Lucide.
3. **Emoji as quick chips** — only inside the small "Why Choose Us" feature grid (handmade, atlas, fair-trade, natural). Migrate to Lucide where possible: `Hand`, `Mountain`, `Handshake`/`HeartHandshake`, `Leaf`.
4. **The WEBERBER mark** — `assets/logo-weberber.svg`. A stylized weaving-loom / "W"-shape glyph in negative space. Treat as a single-color mark; tint via `currentColor`. The wordmark beside it is set type (Playfair Display Bold), not a path.

### Icon style rules
- **Stroke = 1.5px** in 24×24, rounded join + cap. (Lucide default.)
- **Filled** for social glyphs in the footer (Instagram/Pinterest/Facebook), because they're rendered at 20px and need mass.
- **Color = `currentColor`** so icons inherit text color and respect dark backgrounds.
- **Sizing ladder:** 16px (inline-with-text), 20px (nav/footer), 24px (toolbar), 28px (FAB content), 40px (feature-chip circle wrapper, icon at 16–20px inside).
- **Icon chip pattern:** 40×40 circle, `bg-primary/10`, primary-tinted icon centered.

### What NOT to do
- Don't draw your own SVG logo from scratch — use `assets/logo-weberber.svg`.
- Don't mix outline + filled icon sets within one screen. Pick a row.
- Don't use Material/Google fonts icons or Heroicons unless explicitly substituting Lucide for parity.
- Don't decorate with emoji in headlines or body copy.

---

## Open caveats

- **Fonts are CDN-linked from Google Fonts** (`Playfair Display`, `Inter`). The original codebase uses `next/font` with Geist + presumably `next/font/google` for Inter & Playfair (see `globals.css`). No `.woff2` files are bundled in this design system — if you need offline-safe assets, drop them in `fonts/` and update the `@import` in `colors_and_type.css`.
- The "feature chip" emoji set (✋ 🏔️ 🤝 🌿) is a stand-in. Recommend swapping for Lucide.
- Only English copy is wired up here; Arabic/RTL exists in i18n routing but `messages/ar/common.json` was not present.
